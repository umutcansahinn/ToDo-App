package com.umutcansahin.todoapp.domain.mapper

import com.umutcansahin.todoapp.data.local.ToDoEntity


private fun ToDoEntity.to