package com.umutcansahin.todoapp.domain.use_case

import com.umutcansahin.todoapp.data.local.ToDoEntity
import com.umutcansahin.todoapp.domain.repository.ToDoRepository
import javax.inject.Inject

class InsertOrUpdateToDoUseCase @Inject constructor(
    private val repository: ToDoRepository
) {

    suspend operator fun invoke(toDo: ToDoEntity,isInsert: Boolean) {
        if (isInsert) {
            repository.insertToDo(toDo = toDo)
        }else {
            repository.updateToDo(toDo = toDo)
        }
    }
}