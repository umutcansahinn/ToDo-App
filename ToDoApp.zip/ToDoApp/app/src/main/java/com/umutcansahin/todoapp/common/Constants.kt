package com.umutcansahin.todoapp.common


object Constants {
    const val DATABASE_NAME = "toDo_database"

}