package com.umutcansahin.todoapp.domain.uimodel

import android.os.Parcelable


@Parcelize
data class ToDoUIModel(
    val id: Int,
    val name: String,
    val isDone: Boolean

): Parcelable
